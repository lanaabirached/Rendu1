These are the files that you need to implement for rendu1 and rendu2 
functions named "rendu1_rayon_intersecte", and "rendu2_rayon_propagate". 
Your TODO list for each rendu are given in the rendu1.h and rendu2.h
files respectively.
- You should simply copy and paste these files into your project folder.
- Before you start the implementation open the rendu1.c and rendu2.c
files and enter how many group members you have in your group and
the SCIPER ids of these members.
- You should have the implementations of the functions with the correct
return values.
