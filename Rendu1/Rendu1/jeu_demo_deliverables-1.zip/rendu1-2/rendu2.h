/* 
 * Project: Jeu de Reflexion
 * Nom: rendu2.h
 * Description: This header file is required to grade your project. Check
 * 				Rendu document for the specifications.
 * 
 * 				TODO:
 * 					1) Open rendu2.c and set the values as explained to
 * 					   RENDU2_NB_GROUP_MEMBERS and rendu2_sciper_ids.
 * 					2) Implement the function "rendu2_rayon_propagate" 
 * 					   in rendu2.c file.
 * 					3) You should check if your submission is ok
 * 					   with the script named "rendu_submission_check.sh"
 * 					   by using "your final .zip file" and the main file
 * 					   we deliver you whose name is "rendu2_check.cpp".
 * 
 *				NOT TODO!:
 * 					1) DO NOT TOUCH THE PROTOTYPE of 
 * 					   "rendu2_rayon_propagate"!. 
 * 					2) DO NOT TOUCH THE OTHER FUNCTIONS AND DEFINITIONS 
 * 					   MADE IN rendu2.h and rendu2.c.
 * 
 * 				OPTIONAL:
 * 						You can add more functions to it as long
 * 						as your project passes the submission check test.
 * 
 */


#ifndef __RENDU2_H__
#define __RENDU2_H__


// DO NOT TOUCH THE PART BELOW!
unsigned int rendu2_rayon_propagate (float dx, float dy, 
									 float ux, float uy,
									 int nbDisque, float tabDisque[][3], 
									 short tabHit[]);
                                     
int rendu2_get_nb_students(void);

void rendu2_get_sciper_ids(int student_sciper_ids[]);
							   
#endif
