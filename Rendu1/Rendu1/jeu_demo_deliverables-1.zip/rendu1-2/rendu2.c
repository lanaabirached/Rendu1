
// Assign the number of group members to the symbol "NB_GROUP_MEMBERS"
#define RENDU2_NB_GROUP_MEMBERS 2

// Assign the sciper ids of your group members to the array below
// i.e Replace the 21 and 22 by your sciper ids
static int rendu2_sciper_ids[RENDU2_NB_GROUP_MEMBERS] = {21, 22};

unsigned int rendu2_rayon_propagate ( float dx, float dy, 
									  float ux, float uy,
									  int nbDisque, float tabDisque[][3], 
									  short tabHit[])
{
	/*
	 * TODO: Implement the function body.
	 * 		 Don't forget to change the return value.
	 */
	return 0;
}


///// DO NOT TOUCH THE PART BELOW! /////
int rendu2_get_nb_students(void)
{
	return RENDU2_NB_GROUP_MEMBERS;
}

void rendu2_get_sciper_ids(int student_sciper_ids[])
{
	int i = 0;
	for(; i < RENDU2_NB_GROUP_MEMBERS; ++i)
		student_sciper_ids[i] = rendu2_sciper_ids[i];
}
///// DO NOT TOUCH THE PART ABOVE /////


