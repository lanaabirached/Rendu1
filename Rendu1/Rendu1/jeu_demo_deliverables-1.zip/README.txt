This folder includes four subfolders:
	1) error: It includes the error library that you need for the first 
	rendu.
	2) jeu_demo: It includes the demo application together with the test 
	files.
	3) rendu1_2: It includes the rendu1.h, rendu1.c, rendu2.h and 
	rendu2.c files that you need to implement.
	4) submission_check: It includes the scripts and other necessary files
	 that you can ensure that your submission can be evaluated by our 
	 autograding tools.
