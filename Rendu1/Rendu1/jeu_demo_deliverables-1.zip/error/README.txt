You have to use the error library that we provide you to report the
errors in the format we want so that we can autograde your projects.
For making a test if you follow the specs properly please check the
folder submission_check.
