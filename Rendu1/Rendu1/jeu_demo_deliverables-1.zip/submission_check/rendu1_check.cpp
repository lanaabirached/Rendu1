/*
 * Provide this simple file to "rendu_submission_check.sh" to ensure that
 * our autograders can process your submission.
 * You should not modify this file!
 */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>

extern "C"
{
	#include "rendu1.h"
};

namespace
{
	const float RENDU1_EPSILON  = 0.001;
	const float EXPECTED_RESULT = 9.0;
};

int main(int argc, char** argv)
{
	float result = rendu1_rayon_intersecte(10.0, 0.0, -1.0, 0.0, 
										   0.0, 0.0, 1.0);
	
	int nb_students = rendu1_get_nb_students();
	
	int sciper_ids[nb_students];
	rendu1_get_sciper_ids(sciper_ids);
	
	printf("Your sciper ids are: ");
	int i = 0;
	for(; i < nb_students; ++i)
		printf("%d ", sciper_ids[i]);
	printf("\n");
	
	if(fabs(result - EXPECTED_RESULT) < RENDU1_EPSILON)
		printf("Test has passed!\n");
	else
		printf("Test has failed!\n");
	return EXIT_SUCCESS;
}
