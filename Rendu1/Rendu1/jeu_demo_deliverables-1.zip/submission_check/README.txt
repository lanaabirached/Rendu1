You should open the given two scripts "rendu1_error_check.sh" and
rendu_submission_check.sh with a text editor and follow the steps
explained there to make sure that your project is compatible with our
autograding tool.

Note that you might need to add execution right to yourself to run
the scripts. For this use the chmod command as follows:
chmod 755 *
It would assign you read/write/execute rights for all the files
in the folder you run that command.
