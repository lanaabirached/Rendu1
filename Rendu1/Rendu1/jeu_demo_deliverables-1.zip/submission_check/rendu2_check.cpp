/*
 * Provide this simple file to "rendu_submission_check.sh" to ensure that
 * our autograders can process your submission.
 * You should not modify this file!
 */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>

extern "C"
{
	#include "rendu2.h"
};

int main(int argc, char** argv)
{
	int nbDisque = 1;
	float tabDisque[1][3] = {{0.0, 0.0, 1.0}};
	short tabHit[1];
	unsigned int result = rendu2_rayon_propagate(10.0, 0.0, 0.0, 1.0, 
										         nbDisque, tabDisque, 
												 tabHit);
	
	int nb_students = rendu2_get_nb_students();
	
	int sciper_ids[nb_students];
	rendu2_get_sciper_ids(sciper_ids);
	
	printf("Your sciper ids are: ");
	int i = 0;
	for(; i < nb_students; ++i)
		printf("%d ", sciper_ids[i]);
	printf("\n");
	
	if(result == 0)
		printf("Test has passed!\n");
	else
		printf("Test has failed!\n");
	return EXIT_SUCCESS;
}
